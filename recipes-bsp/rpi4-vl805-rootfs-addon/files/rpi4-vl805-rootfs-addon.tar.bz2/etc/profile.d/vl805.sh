#!/bin/bash

done_func() {
echo "Nothing to do; Already here."
}

flash_func() {
/opt/via805/vl805_flash.sh flash
}

main_func() {
lsusb | grep -qie "via.*labs" && done_func || flash_func
}

main_func | tee /dev/kmsg
