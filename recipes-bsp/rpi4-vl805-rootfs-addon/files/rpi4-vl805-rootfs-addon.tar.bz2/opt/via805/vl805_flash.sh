#!/bin/bash

VIA805_LIB_HOME="/opt/via805"
VIA805_UTIL=vl805
FW="fw00013705_020000.bin"
DEF_LOG_LEVEL=0
DEF_PRINT_LEVEL=4

opts=${1:-"show"}
if [[ "$(basename ${0})" == *"flash" ]] ; then
	opts="flash"
elif [[ "$(basename ${0})" == *"show" ]] ; then
	opts="show"
fi

function do_vl805_flash() {
	cd ${VIA805_LIB_HOME}
	./${VIA805_UTIL} -l ${DEF_LOG_LEVEL} -p ${DEF_PRINT_LEVEL} -w ${VIA805_LIB_HOME}/${FW}	
	cd - &>/dev/null
}

function do_vl805_show() {
	${VIA805_LIB_HOME}/${VIA805_UTIL} -l ${DEF_LOG_LEVEL} -p ${DEF_PRINT_LEVEL}	
}

command -v do_vl805_${opts} &>/dev/null && do_vl805_${opts} || true
